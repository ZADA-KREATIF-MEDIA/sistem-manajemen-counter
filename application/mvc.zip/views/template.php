<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Andi Hoerudin">
  <meta name="author" content="Andi Hoerudin">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>iHardware - Yogyakarta </title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css"  rel="stylesheet" type="text/css">

  <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

  <link href="<?php echo base_url() ?>assets/vendor/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <!-- Jquery -->
  <!-- Jquery UI CSS -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-ui/jquery-ui.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-ui/jquery-ui.structure.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/jquery-ui/jquery-ui.theme.min.css">
  <!-- Sweeat Alert CSS -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/sweetalert2/sweetalert2.min.css">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/styles.css" rel="stylesheet">
</head>

<body class="sb-nav-fixed" id="page-top">
  <!-- Navigation-->
  <?php $this->load->view('partials/_navbar')?>
  <div id="layoutSidenav_content">
    <main>
      <div class="container-fluid">
        <h1 class="mt-4"></h1>
        <div class="row">
          <?php echo $contents ?>
        </div>
      </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    </main>
    <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid">
            <div class="d-flex align-items-center justify-content-between small">
                <div class="text-muted">Copyright &copy; iHardware 2020</div>
                
            </div>
        </div>
    </footer>
  </div>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Modal Loading-->
    <div class="modal fade text-center" id="loader" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="false">
      <div class="modal-dialog modal-dialog-centered background-none-modal" role="document">
          <div class="w-100 text-center">
              <div class="spinner-border text-primary" role="status">
                  <span class="sr-only">Loading...</span>
              </div>
              <h2 class="text-light">Please Wait..</h2>
          </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/scripts.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- <script src="<?php echo base_url() ?>assets/vendor/jquery/jquery-3.5.0.min.js"></script> -->
    <!-- Jquery Plugin-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery-ui/jquery-ui.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/datatables/responsive.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/sweetalert2/sweetalert2.all.min.js"></script>
    <script>
      function convertToRupiah(angka){
          var rupiah = '';        
          var angkarev = angka.toString().split('').reverse().join('');
          for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
          return rupiah.split('',rupiah.length-1).reverse().join('');
      }
      $(document).ready(function () {
        $("#dataTable").DataTable({});
        $('.uang').mask('000.000.000', {reverse:true});
        $( function() {
          $( ".datepicker" ).datepicker({
            dateFormat: 'dd-mm-yy'
          });
        });
        // Module Penjualan
        $("select#kode_barang").change(function(){
            var id_barang = $(this).val();
            $("#imei").text(id_barang);
            $("#imei").val(id_barang);
            $.ajax({
              url     : "<?php echo base_url('transaksi/get_harga_jual'); ?>",
              method  : "POST",
              data    : {id_barang : id_barang},
              success: function(res){
                var data = $.parseJSON(res);
                $("#kodePembelian").val(data.kode_pembelian);
                $("#namaBarang").val(data.nama_barang);
                $("#hargaBeli").val(convertToRupiah(data.harga_beli));
                $("#hargaBarang").val(data.harga_beli);
              }
            })
        });
      });
      // Module Service Bagian Edit
      function deleteHW(id){
	      $("#hapusHW_"+id).remove();
        Swal.fire({
          text: "Apakah anda yakin akan menghapus part Hardware ini!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('service/destroy_service_part'); ?>",
              method  : "POST",
              data    : {id_service : id},
              success : function(res){
                Swal.fire(
                'Deleted!',
                'Part Berhasil di hapus.',
                'success'
                );
                location.reload();
              }
            });
          }
        });
	    }
      function deleteSW(id){
        $("#hapusSW_"+id).remove();
        Swal.fire({
          text: "Apakah anda yakin akan menghapus part software ini!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('service/destroy_service_software');?>",
              method  : "POST",
              data    : {id_service : id},
              success : function(res){
                Swal.fire(
                'Deleted!',
                'Part Berhasil di hapus.',
                'success'
                );
                location.reload();
              }
            })
            Swal.fire(
            'Deleted!',
            'Part Berhasil di hapus.',
            'success'
            );
          }
        });
      }
      function hapusPart(id){
        Swal.fire({
          text: "Apakah anda yakin akan menghapus data part ini?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            window.location.href="<?php echo base_url();?>service/delete_part/"+id
          }
        })
      }
      function hapusService(id)
    {
        // console.log(id);
        Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Akan menghapus data service customer?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya',
        cancelButtonText : 'Tidak'
        }).then((result) => {
        if (result.value) {
            $.ajax({
                url     : "<?php echo base_url('service/delete'); ?>",
                method  : "POST",
                data    : {id_customer : id},
                success:function(res){
                    // console.log(res)
                    Swal.fire(
                        'Deleted!',
                        'Data customer berhasil di hapus.',
                        'success'
                    );
                    location.reload();
                }
            })
        }
        })
    }
      // Module Laporan Pembelian
      function alertHapus(id){
        Swal.fire({
          title: 'Apakah Anda Yakin?',
          text: "Akan menghapus data laporan pembelian?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya',
          cancelButtonText : 'Tidak'
        }).then((result) => {
          if (result.value) {
              $.ajax({
                  url     : "<?php echo base_url('Laporan_pembelian/hapus'); ?>",
                  method  : "POST",
                  data    : {kode_pembelian : id},
                  success:function(res){
                      Swal.fire(
                          'Deleted!',
                          'Data laporan pembelian berhasil di hapus.',
                          'success'
                      );
                      location.reload();
                  }
              })
          }
        })
      }
      function editPembelian(id){
        $.ajax({
          url     : "<?php echo base_url('laporan_pembelian/get_harga_keterangan_pembelian');?>",
          method  : "POST",
          data    : {id : id},
          beforeSend: function() {
            $('#loader').modal({backdrop:'static',keyboard:false})
              setTimeout(function(){
              $('#loader').modal('hide');
            }, 1000);
          },
          success : function(res){
            var data = $.parseJSON(res);
            $("#kodePembelian").val(data.kode_pembelian);
            $("#hargaPembelian").val(convertToRupiah(data.harga_beli));
            $("#keterangan").val(data.keterangan);
            $("#keterangan").text(data.keterangan);
            $('#laporanPenjualanModal').modal('show');
          }
        });
      }
      $("#pembayaran").change(function(){
        var status = $("#pembayaran").val();
        if(status == "hutang"){
          $("#blockUangMuka").removeClass('d-none');
          $("#blockTanggalJatuhTempo").removeClass('d-none');
        }else{
          $("#blockUangMuka").addClass('d-none');
          $("#blockTanggalJatuhTempo").addClass('d-none');
        }
      });
      // Module Laporan Penjualan 
      function hapusLaporanPenjualan(id){
        Swal.fire({
          title: 'Apakah Anda Yakin',
          text: "Akan menghapus data laporan penjualan?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya',
          cancelButtonText : 'Tidak'
        }).then((result) => {
          if (result.value) {
              $.ajax({
                  url     : "<?php echo base_url('Laporan_penjualan/hapus'); ?>",
                  method  : "POST",
                  data    : {id : id},
                  success:function(res){
                      Swal.fire(
                          'Deleted!',
                          'Data laporan penjualan berhasil di hapus.',
                          'success'
                      );
                      location.reload();
                  }
              })
          }
        })
      }
      // Module Barang 
      function ubahInStock(id){
        Swal.fire({
          text: "Apakah anda yakin akan menghapus data barang ini dari keranjang transaksi?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('barang/hapus_tmp');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                Swal.fire(
                  'Deleted!',
                  'Barang berhasil di hapus.',
                  'success'
                );
                location.reload();
              }
            });
          }
        })
      }
      function hapusBarang(id){
        Swal.fire({
          text: "Apakah anda yakin akan menghapus data barang?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('barang/hapus');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                Swal.fire(
                  'Deleted!',
                  'Barang berhasil di hapus.',
                  'success'
                );
                location.reload();
              }
            });
          }
        })
      }
      // Module Pemasukan 
      function hapusPemasukan(id){
        Swal.fire({
          text: "Apakah anda yakin akan menghapus data pemasukan?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('pemasukan/hapus');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                Swal.fire(
                  'Deleted!',
                  'Barang berhasil di hapus.',
                  'success'
                );
                location.reload();
              }
            });
          }
        })
      }
      // Module Pengeluaran 
      function hapusPengeluaran(id){
        Swal.fire({
          text: "Apakah anda yakin akan menghapus data pengeluaran?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('pengeluaran/hapus');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                Swal.fire(
                  'Deleted!',
                  'Barang berhasil di hapus.',
                  'success'
                );
                location.reload();
              }
            });
          }
        })
      }
      // Module Gaji 
      function hapusGaji(id){
        Swal.fire({
          text: "Apakah anda yakin akan menghapus data gaji?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('gaji/hapus');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                Swal.fire(
                  'Deleted!',
                  'Barang berhasil di hapus.',
                  'success'
                );
                location.reload();
              }
            });
          }
        })
      }
      // Module Saldo Awal
      function hapusSaldoAwal(id){
        Swal.fire({
          text: "Anda yakin akan menghapus data saldo awal?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            window.location.href="<?php echo base_url();?>saldo_awal/destroy/"+id
          }
        })
      }
      // Module Piutang
      $("select#piutang").change(function(){
        var id = $(this).val();
        $.ajax({
          url     : "<?php echo base_url('piutang/get_harga_piutang');?>",
          method  : "POST",
          data    : {id:id},
          success: function(res){
            var hasil = $.parseJSON(res);
            $("#jumlah_hutang").val(convertToRupiah(hasil.nominal_piutang));
          }
        })
        
      });
      function restartPiutang(id){
        Swal.fire({
          title: 'Apakah anda yakin menghapus data transaksi piutang?',
          text: "Jika anda menghapus data piutang berarti seluruh histori transaksi akan hilang dan kembali ke transaksi awal",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('piutang/reset_data_piutang');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                location.reload();
              }
            });          
          }
        });
      }
      // Module Hutang
      $("select#hutang").change(function(){
        var id = $(this).val();
        $.ajax({
          url     : "<?php echo base_url('hutang/get_harga_hutang');?>",
          method  : "POST",
          data    : {id:id},
          success: function(res){
            var hasil = $.parseJSON(res);
            $("#jumlah_hutang").val(convertToRupiah(hasil.nominal_hutang));
          }
        })
        
      });
      function restartHutang(id){
        Swal.fire({
          title: 'Apakah anda yakin menghapus data transaksi hutang?',
          text: "Jika anda menghapus data hutang berarti seluruh histori transaksi akan hilang dan kembali ke transaksi awal",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#3085d6',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url     : "<?php echo base_url('hutang/reset_data_hutang');?>",
              method  : "POST",
              data    : {id : id},
              success : function(res){
                location.reload();
              }
            });          
          }
        });
      }
      // Modul Export Excel Laporan Bulanan & Harian
      function exportExcelBulanan(tanggal){
        if(tanggal != 0){
          window.location.href = "<?php echo base_url();?>laporan_laba_rugi/export_bulanan/"+tanggal
        }else{
          window.location.href = "<?php echo base_url();?>laporan_laba_rugi/export_bulanan"
        }
      }
      function exportExcelHarian(hari){
        if(hari != 0){
          window.location.href = "<?php echo base_url();?>laporan_laba_rugi/export_harian/"+hari
        }else{
          window.location.href = "<?php echo base_url();?>laporan_laba_rugi/export_harian"
        }
      }
      /*--------- Error & Success Handling ---------*/
      /* Modul Transaksi */
      <?php if(isset($_SESSION['msg'])&&$_SESSION['msg']=="tmp_kosong"):?>
        Swal.fire({
          text: "Harap mengisikan data transaksi penjualan terlebih dahulu!",
          icon: 'warning',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']);?>
          }
        })
      <?php endif;?>
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="berhasil simpan temp"):?>
        Swal.fire({
          text: "Berhasil di tambahkan di keranjang penjualan",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        })
      <?php endif;?>
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="transaksi success"):?>
        Swal.fire({
          text: "Transaksi Penjualan Berhasil",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      /* Modul Pembelian */
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="pembelian sukses"):?>
        Swal.fire({
          text: "Transaksi Pembelian Berhasil",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      /* Modul Laporan Pembelian */
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="edit laporan pembelian berhasil"):?>
        Swal.fire({
          text: "Edit Data Laporan Pembelian Berhasil",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      /* Modul Laporan Penjualan */
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="edit laporan penjualan berhasil"):?>
        Swal.fire({
          text: "Edit Data Laporan Penjualan Berhasil",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      /* Modul Pemasukan */
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="pemasukan success"):?>
        Swal.fire({
          text: "Berhasil Menambahkan Data Pemasukan",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="edit pemasukan success"):?>
        Swal.fire({
          text: "Berhasil Edit Data Pemasukan",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      /* Modul Pengeluaran */
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="tambah pengeluaran"):?>
        Swal.fire({
          text: "Berhasil Menambahkan Data Pengeluaran",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="edit pengeluaran"):?>
        Swal.fire({
          text: "Berhasil Edit Data Pengeluaran",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      /* Modul Gaji */
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="tambah gaji"):?>
        Swal.fire({
          text: "Berhasil Menambahkan Data Gaji",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
      <?php if(isset($_SESSION['msg']) && $_SESSION['msg']=="edit gaji"):?>
        Swal.fire({
          text: "Berhasil Edit Data Gaji",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.value) {
            <?php unset($_SESSION['msg']); ?>
          }
        });
      <?php endif;?>
    </script>
  </div>
</body>

</html>