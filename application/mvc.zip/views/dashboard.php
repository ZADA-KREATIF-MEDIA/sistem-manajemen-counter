<div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Dashboard Penjualan</li>
    </ol>
    <!-- Icon Cards-->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                        <div class="alert alert-success">
                           Welcome : <?php echo $this->session->userdata('nama') ?>
                        </div>
                        <div class="card">
  <div class="card-header">
    <?= DATE("d-m-Y") ?>
  </div>
  <div class="card-body">
    <h5 class="card-title">Penjualan Barang - <?php echo $this->session->userdata('nama')?></h5>
    <p class="card-text">
    <ul class="list-group">
     <?php 
                $total=0;
               foreach($grafik as $trans):
			    {
					echo "<li class='list-group-item'>".$trans->nama_barang."-".$trans->harga_jual."</li>";
                }
                $total+= $trans->harga_jual;
                 endforeach;
                ?>
                </ul>
                <hr>
                <h5>Jumlah Penjualan = <?= count($grafik); ?> Barang</h5>
                <h5>Total Pendapatan = Rp. <?= number_format($total,0,'.','.')?></h5>
  </div>
</div>



                </div>
            </div>
        </div>
        
    
        
  </div>
</div>

